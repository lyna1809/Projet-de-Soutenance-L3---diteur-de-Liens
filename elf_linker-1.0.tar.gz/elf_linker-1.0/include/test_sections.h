#ifndef __TEST_SECTIONS_H__
#define __TEST_SECTIONS_H__
#include "modification_elf.h"

void test_elf_modifications(FILE* output);

#endif // __TEST_SECTIONS_H__